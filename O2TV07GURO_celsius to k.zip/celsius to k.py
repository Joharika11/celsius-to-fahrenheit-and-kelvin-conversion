celsius = float(input())
fahrenheit = (celsius * 9/5) + 32
kelvin = celsius + 273.15
print(str(celsius)+"°C is equal to "+ str(fahrenheit)+"°F")
print(str(celsius)+"°C is equal to " +str(kelvin)+"K")